import React from 'react';
import Login from './components/Login';
import Signup from './components/Signup';
import './App.css';

function App() {
    return (
        <div className="App">
            <div className="container">
                <Login />
                <Signup />
            </div>
        </div>
    );
}

export default App;
